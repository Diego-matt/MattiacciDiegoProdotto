/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package mattiaccidiegoprodotto;

/**
 *
 * @author matti_3x0xxn1
 */
public class MattiacciDiegoProdotto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
     Prodotto p = new Prodotto( "cocco" , 200, 15, 3 ) ;
     Prodotto p1 = new Prodotto( "cocco" , 200, 15, 3 ) ;   
        
     p.vendiProdotto(1);
     
     System.out.println(p.toString());
     
     System.out.println(p.equals(p1));
     
     
    }
    
}
