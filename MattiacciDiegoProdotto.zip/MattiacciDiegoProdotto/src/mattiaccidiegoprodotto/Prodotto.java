/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mattiaccidiegoprodotto;

import java.util.Objects;

/**
 *
 * @author matti_3x0xxn1
 */
public class Prodotto {
    
private String nome;
private double peso;
private double prezzo;
private int pezzi;

/**
 * metodo costruttore
 * @param nome del prodotto
 * @param peso del prodotto
 * @param prezzo del prodotto
 * @param pezzi del prodotto
 */
public Prodotto(String nome, double peso,double prezzo, int pezzi){
    
  this.nome = nome;
  this.peso = peso;
  this.prezzo = prezzo;
  this.pezzi = pezzi;
    
}

public String getNome(){
    
  return this.nome;  
    
}
public double getPeso(){
    
  return this.peso;  
    
}
public double getPrezzo(){
    
  return this.prezzo;  
    
}
public int getPezzi(){
    
  return this.pezzi;  
    
}
/**
 * set del nuovo peso
 * @param peso
 * @return il nuovo peso
 */
public double setPeso(int peso){
    
  return this.peso = peso;  
    
}

  
/**
 * set del nuovo prezzo
 * @param prezzo
 * @return il nuovo prezzo
 */
public double setPrezzo(int prezzo){
    
  return this.prezzo = prezzo;  
    
}
/**
 * metodo per vendere il prdotto
 * @param num pezzi che voglio prendere
 */
void vendiProdotto(int num){
    
 if (num > 0 && num <= pezzi ) {
     
   double prezzoTot = prezzo * num;
   pezzi = pezzi - num; 
 }

}
 /**
  * rifornisce il prodotto
  */
public void rifornisci()
{
  
    this.pezzi++;
}

/**
 * incrementa pezzi di 1 alla volta
 * @param numI 
 */
public void incrementaPezzi(int numI){
  
 if(numI > 0)  {
  pezzi = pezzi + numI;     
 }  
  
    
    
}
  
 /**
  * metodo del prodotto completo
  * @return 
  */
 public String toString(){
     
     
   return "prodotto" + " " + this.nome + " " + "peso" + " " + this.peso + " " + "prezzo" + " " + this.prezzo + " " + "pezzi" + " "  + this.pezzi;
     
     
 } 
  
    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + Objects.hashCode(this.nome);
        return hash;
    }

    /**
     * serve per confrontare due prodotti o piu 
     * @param obj
     * @return 
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Prodotto other = (Prodotto) obj;
        
        // Sostituito il vecchio return true fisso con il confronto reale
        return Objects.equals(this.nome, other.nome); 
    }
  
  
}
